<?php
echo "This is the View";
die();
?>
