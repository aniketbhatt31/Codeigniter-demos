-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2016 at 06:58 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `temp`
--

-- --------------------------------------------------------

--
-- Table structure for table `temp_register`
--

CREATE TABLE IF NOT EXISTS `temp_register` (
`id` int(11) NOT NULL,
  `temp_name` varchar(255) NOT NULL,
  `temp_email` varchar(255) NOT NULL,
  `temp_mobile` varchar(255) NOT NULL,
  `temp_gender` varchar(255) NOT NULL,
  `temp_image` varchar(255) NOT NULL,
  `temp_password` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_register`
--

INSERT INTO `temp_register` (`id`, `temp_name`, `temp_email`, `temp_mobile`, `temp_gender`, `temp_image`, `temp_password`) VALUES
(38, 'sfg', 'a@gmail.com', '132', 'male', 'upload/Chrysanthemum.jpg', '123'),
(39, 'sfg', 'a@gmail.com', '132', 'male', 'upload/1450776940Chrysanthemum.jpg', '123'),
(40, 'ani', 'a@gmail.com', '123', 'male', 'upload/1450777106Desert.jpg', '123'),
(78, 'sdgfdg', 'asfd@sdf.df', '0123456789', 'male', 'upload/1450784475Desert.jpg', 'asfddfsdgfgf'),
(80, 'sdjge', 'jdkbf@sdfb.sd', '0123456789', 'male', 'upload/1450785013Hydrangeas.jpg', 'asdfsdgfd'),
(81, 'dfghdf', 'asd@sdaf.df', '0123456789', 'male', 'upload/1450785120Desert.jpg', '12345678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `temp_register`
--
ALTER TABLE `temp_register`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `temp_register`
--
ALTER TABLE `temp_register`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
