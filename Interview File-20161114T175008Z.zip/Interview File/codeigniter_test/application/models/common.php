<?php
Class Common extends CI_Model
{
    //This function get all records from table by name
    function getallrecordbytablename($tablename,$data = '*',$limit = '', $offset = '', $sortby = 'id', $orderby = 'DESC',$conditionarray='')
    {
        
        $this->db->order_by($sortby,$orderby);
		
        //Setting Limit for Paging
        if( $limit != '' && $offset == 0)
        { $this->db->limit($limit); }
        else if( $limit != '' && $offset != 0)
        {	$this->db->limit($limit, $offset);	}

        //Executing Query
        $this->db->select($data);
        $this->db->from($tablename);
        if($conditionarray!='')
        {
        $this->db->where($conditionarray);
        }
        $query =  $this->db->get();
        if ($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return array();
        }
        
    }
    
    
    function select_max_search_data($tablename,$data,$limit = '', $offset = '', $sortby = '', $orderby = '',$groupby = '',$conditionarray='')
    {
        
        $this->db->order_by($sortby,$orderby);
		
        //Setting Limit for Paging
        if( $limit != '' && $offset == 0)
        { $this->db->limit($limit); }
        else if( $limit != '' && $offset != 0)
        {	$this->db->limit($limit, $offset);	}
        if($groupby!='')
        {
        $this->db->group_by($groupby);
        }
        //Executing Query
        $this->db->select($data);
        $this->db->from($tablename);
        if($conditionarray!='')
        {
        $this->db->where($conditionarray);
        }
        $query =  $this->db->get();
        if ($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return array();
        }
        
    }
    
    // insert database
    function insert_data($data,$tablename)
    {
        if($this->db->insert($tablename,$data))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    // insert database return id
    function insert_data_getid($data,$tablename)
    {
        if($this->db->insert($tablename,$data))
        {
            return $this->db->insert_id();
        }
        else
        {
            return false;
        }
    }
    
    // update database
    function update_data($data,$tablename,$columnname,$columnid)
    {
        $this->db->where($columnname,$columnid);
        if($this->db->update($tablename,$data))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
       // select data using multiple conditions
    function select_data_by_condition($tablename, $contition_array = array(), $data = '*', $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str = array()) {
        $this->db->select($data);

        if (!empty($join_str)) {
            foreach ($join_str as $join) {
                if ($join['join_type'] == '') {
                $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id']);
                }
                else{
                    $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id'], $join['join_type']);
                }
            }
        }
if(count($contition_array)!=0)
{
        $this->db->where($contition_array);
}


        //Setting Limit for Paging
        if ($limit != '' && $offset == 0) {
            $this->db->limit($limit);
        } else if ($limit != '' && $offset != 0) {
            $this->db->limit($limit, $offset);
        }
        //order by query
        if ($sortby != '' && $orderby != '') {
            $this->db->order_by($sortby, $orderby);
        }

        $query = $this->db->get($tablename);

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }
 
    // select data using colum id
   function select_database_id($tablename,$columnname,$columnid,$data='*',$condition_array=array())
    {
        $this->db->select($data);
        $this->db->where($columnname,$columnid);
        if(!empty($condition_array)){
            $this->db->where($condition_array);
        }
        $query = $this->db->get($tablename);
        
        if($query->num_rows()>0)
        {
            return $query->result_array();
        }
        else
        {
            return array();
        }
    }

    // select data using multiple conditions and search keyword
    function select_data_by_search($tablename, $search_condition, $contition_array = array(), $data = '*', $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str='') {
        $this->db->select($data);
        if (!empty($join_str)) {
            foreach ($join_str as $join) {
                $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id']);
            }
        }
        if(count($contition_array)!=0)
        {
        $this->db->where($contition_array);
        }
        $this->db->where($search_condition);

        //Setting Limit for Paging
        if ($limit != '' && $offset == 0) {
            $this->db->limit($limit);
        } else if ($limit != '' && $offset != 0) {
            $this->db->limit($limit, $offset);
        }
        //order by query
        if ($sortby != '' && $orderby != '') {
            $this->db->order_by($sortby, $orderby);
        }

        $query = $this->db->get($tablename);
        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }
    
    // delete data
    function delete_data($tablename,$columnname,$columnid)
    {
        $this->db->where($columnname,$columnid);
        if($this->db->delete($tablename))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    // change status
    function change_status($data,$tablename,$columnname,$columnid)
    {
        $this->db->where($columnname,$columnid);
        if($this->db->update($tablename,$data))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //get all record 
     function get_all_record($tablename,$data='*',$sortby='',$orderby='')
    {
        $this->db->select($data);
        $this->db->from($tablename);
        //$this->db->where('status','Enable');
        if($sortby != '' && $orderby != "")
        {
            $this->db->order_by($sortby,$orderby);
        }
        $query = $this->db->get();
        if($query ->num_rows()>0)
        {
            return $query->result_array();
        }
        else
        {
            return array();
        }
    }
    
    //table records count
    function get_count_of_table($table)
    {
        $query = $this->db->count_all($table);
        return $query;
    }
    
}