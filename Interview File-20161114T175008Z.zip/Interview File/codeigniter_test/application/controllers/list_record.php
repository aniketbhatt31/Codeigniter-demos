<?php if (!defined('BASEPATH'))    exit('No direct script access allowed');

class List_record extends CI_Controller {

    public $data;

    public function __construct() {
        parent::__construct();
        
        $this->load->library('pagination');
        $this->config->load('paging', TRUE);
        $this->paging = $this->config->item('paging');
               
    }

    public function index() {
     
	 	$result = $this->common->select_data_by_condition('register');
		
		//echo '<pre>';
		//print_r($result);
		//die();
		
        $this->load->view('list_view', $this->data);
    }

}
